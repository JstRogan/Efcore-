# GameStore Console App

Магазин видеоигр на C# с использованием Entity Framework Core.

## Features

- Регистрация пользователей
- Просмотр и покупка игр
- История заказов
- Управление каталогом игр для администратора

## Запуск

```bash
dotnet ef migrations add Init
dotnet ef database update
dotnet run
```
