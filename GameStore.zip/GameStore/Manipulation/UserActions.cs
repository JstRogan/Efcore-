using System;
using System.Linq;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using GameStore.Entities;

namespace GameStore.Manipulation
{
    public static class UserActions
    {
        public static void TopUpBalance(Data.GameStoreContext context, User user)
        {
            Console.Write("Введите сумму для пополнения: ");
            if (decimal.TryParse(Console.ReadLine(), out decimal amount))
            {
                user.Balance += amount;
                context.SaveChanges();
                Console.WriteLine($"Баланс успешно пополнен. Текущий баланс: {user.Balance}₽");
            }
            else
            {
                Console.WriteLine("Некорректная сумма.");
            }
        }

        public static void ViewGameCatalog(Data.GameStoreContext context)
        {
            var games = context.Games.Include(g => g.Genre).Include(g => g.Platform).ToList();
            Console.WriteLine("Каталог игр:");
            foreach (var game in games)
            {
                Console.WriteLine($"ID: {game.Id} | Название: {game.Title} | Жанр: {game.Genre.Name} | Платформа: {game.Platform.Name} | Цена: {game.Price}₽");
            }
        }

        public static void BuyGame(Data.GameStoreContext context, User user)
        {
            ViewGameCatalog(context);
            Console.Write("Введите ID игры для покупки: ");
            if (!int.TryParse(Console.ReadLine(), out int gameId))
            {
                Console.WriteLine("Неверный формат ID.");
                return;
            }
            var game = context.Games.Find(gameId);
            if (game == null)
            {
                Console.WriteLine("Игра не найдена.");
                return;
            }
            if (user.Balance < game.Price)
            {
                Console.WriteLine("Недостаточно средств на балансе.");
                return;
            }
            var order = new Order { UserId = user.Id, Date = DateTime.Now, TotalAmount = game.Price, OrderItems = new List<OrderItem>() };
            var orderItem = new OrderItem { GameId = game.Id, Quantity = 1, TotalPrice = game.Price };
            order.OrderItems.Add(orderItem);
            context.Orders.Add(order);
            user.Balance -= game.Price;
            context.SaveChanges();
            Console.WriteLine($"Вы успешно купили игру: {game.Title}");
        }

        public static void ViewPurchaseHistory(Data.GameStoreContext context, User user)
        {
            var orders = context.Orders
                .Where(o => o.UserId == user.Id)
                .Include(o => o.OrderItems)
                .ThenInclude(i => i.Game)
                .ToList();

            if (!orders.Any())
            {
                Console.WriteLine("История покупок пуста."); return;
            }
            Console.WriteLine("История покупок:");
            foreach (var order in orders)
            {
                Console.WriteLine($"Дата: {order.Date}, Сумма: {order.TotalAmount}₽");
                foreach (var item in order.OrderItems)
                {
                    Console.WriteLine($"  - {item.Game.Title} | Цена: {item.TotalPrice}₽");
                }
            }
        }
    }
}
