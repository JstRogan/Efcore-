using System;
using GameStore.Entities;
using GameStore.Manipulation;
using Microsoft.EntityFrameworkCore;

namespace GameStore
{
    class Program
    {
        private static string connectionString = "Data Source=localhost;Initial Catalog=GameStore;Integrated Security=True;TrustServerCertificate=True";
        public static User CurrentUser { get; set; }

        static void Main(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<GameStoreContext>();
            optionsBuilder.UseSqlServer(connectionString);

            using (var context = new GameStoreContext(optionsBuilder.Options))
            {
                while (true)
                {
                    Console.WriteLine("1 - Войти как Админ");
                    Console.WriteLine("2 - Войти как Пользователь");
                    Console.WriteLine("3 - Выйти из программы");

                    if (!int.TryParse(Console.ReadLine(), out int choice))
                    {
                        Console.WriteLine("Некорректный ввод!");
                        continue;
                    }

                    switch (choice)
                    {
                        case 1:
                            AdminMenu(context);
                            break;
                        case 2:
                            UserMenu(context);
                            break;
                        case 3:
                            return;
                        default:
                            Console.WriteLine("Некорректный выбор!");
                            break;
                    }
                }
            }
        }

        static void AdminMenu(GameStoreContext context)
        {
            while (true)
            {
                Console.WriteLine("1 - Добавить игру");
                Console.WriteLine("2 - Удалить игру");
                Console.WriteLine("3 - Обновить игру");
                Console.WriteLine("4 - Показать все игры");
                Console.WriteLine("5 - Выйти");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Некорректный ввод!");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        AdminActions.AddGame(context);
                        break;
                    case 2:
                        AdminActions.DeleteGame(context);
                        break;
                    case 3:
                        AdminActions.UpdateGame(context);
                        break;
                    case 4:
                        AdminActions.ShowAllGames(context);
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Некорректный выбор!");
                        break;
                }
            }
        }

        static void UserMenu(GameStoreContext context)
        {
            var auth = new AuthorizationUsers(context);

            while (true)
            {
                Console.WriteLine("1 - Регистрация");
                Console.WriteLine("2 - Войти");
                Console.WriteLine("3 - Назад");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Некорректный ввод!");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        Console.Write("Введите имя: ");
                        string name = Console.ReadLine()!;
                        Console.Write("Введите email: ");
                        string email = Console.ReadLine()!;
                        auth.RegisterUser(name, email);
                        break;
                    case 2:
                        Console.Write("Введите email: ");
                        string loginEmail = Console.ReadLine()!;
                        var user = auth.LoginUser(loginEmail);
                        if (user != null)
                        {
                            CurrentUser = user;
                            UserActionsMenu(context);
                        }
                        break;
                    case 3:
                        return;
                    default:
                        Console.WriteLine("Некорректный выбор!");
                        break;
                }
            }
        }

        static void UserActionsMenu(GameStoreContext context)
        {
            while (true)
            {
                Console.WriteLine("1 - Просмотреть каталог игр");
                Console.WriteLine("2 - Купить игру");
                Console.WriteLine("3 - Пополнить баланс");
                Console.WriteLine("4 - История покупок");
                Console.WriteLine("5 - Выйти");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Некорректный ввод!");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        UserActions.ViewGameCatalog(context);
                        break;
                    case 2:
                        UserActions.BuyGame(context, CurrentUser);
                        break;
                    case 3:
                        UserActions.TopUpBalance(context, CurrentUser);
                        break;
                    case 4:
                        UserActions.ViewPurchaseHistory(context, CurrentUser);
                        break;
                    case 5:
                        return;
                    default:
                        Console.WriteLine("Некорректный выбор!");
                        break;
                }
            }
        }
    }
}
